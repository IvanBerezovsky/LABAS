let world_xPos = 0

let mapArray = []
let bridgeArray = []
let treeArray = []

let numberOfBridges = 3
let bridgeBorder = 500

let numberOfTrees = 10
let treeBorder = 100

let player = {
  xPos: 350,
  yPos: 550,
  speed: 8
}

function drawPlayer()
{
  fill("yellow")
  circle(player.xPos, player.yPos, 60)
}

function drawBridge(x)
{
  fill(0)
  stroke("yellow")
  strokeWeight(5)
  rect(x, 600, 200, 20)
  noStroke()
}

function drawTree(x)
{
  fill(0)
  stroke("green")
  strokeWeight(5)
  rect(x, 600, 20, -150)
  rect(x - 40, 440, 100, -100)
  noStroke()
}

function mapGenerator()
{
  for (let x = 0; x < 2101; x ++) // Creating mapArray
  {
    mapArray.push(x)
  }
  
  for(y = 0; y < 400; y++) // No spawn for bridges
    {
      mapArray[y] = 0
    }
  
  for (x = 0; x < numberOfBridges; x++) // Bridges spawn
  {
    xPos = random(mapArray)
    
    if(mapArray[xPos] == 0 || mapArray[xPos + bridgeBorder] == 0)
    {
      while(mapArray[xPos] == 0 || mapArray[xPos + bridgeBorder] == 0) 
      {  
        xPos = random(mapArray)
      }
    }
    
    for(y = xPos; y < xPos + bridgeBorder; y++)
    {
      mapArray[y] = 0
    }
    
    bridgeArray.push(xPos)
  }
  
  for(let x = 0; x < 2101; x ++) // Recreating mapArray
  {
    mapArray[x] = x
  }
  
  for(let x = 0; x < numberOfBridges; x++)
  {
    for(let y = 0; y < 200; y++)
    {
      mapArray[y + bridgeArray[x]] = 0
    }
  }
  
  for (x = 1; x < numberOfTrees; x++) // Trees spawn
  {
    xPos = random(mapArray)
    
    if(mapArray[xPos] == 0 || mapArray[xPos + treeBorder] == 0)
    {
      while(mapArray[xPos] == 0 || mapArray[xPos + treeBorder] == 0) 
      {  
        xPos = random(mapArray)
      }
    }
    
    for(y = xPos; y < xPos + treeBorder; y++)
    {
      mapArray[y] = 0
    }
    
    treeArray.push(xPos)
  }
}

function setup()
{
  createCanvas(700, 700)
  
  mapGenerator()
}

function draw()
{
  background(0)
  
  for(x = 0; x < numberOfBridges; x++)
  {
    drawBridge(world_xPos + bridgeArray[x])
  }
  
  for(x = 1; x < numberOfTrees; x++)
  {
    drawTree(world_xPos + treeArray[x])
  }

  drawPlayer()
  
  move()
}

function move()
{
  if(player.xPos <= 50 && keyIsDown(65))
  {
    world_xPos += player.speed
  }
  
  else if(player.xPos >= 650 && keyIsDown(68))
  {
    world_xPos -= player.speed
  }
  
  else
  {
    if(keyIsDown(65)) // Движение влево
      {   
        player.xPos = player.xPos - player.speed
      }


      if(keyIsDown(68)) // Движение вправо
      {    
        player.xPos = player.xPos + player.speed
      }
  }
}





















