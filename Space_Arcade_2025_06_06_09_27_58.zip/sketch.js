let music
let explosionSound
let musicButton
let musicSlider
let soundSlider

let score = 0
let gameEnded = false
let minScore = -10
let maxScore = 60

let ship = {
  xPos: 350,
  yPos: 600,
  canShoot: true,
  shootTimer: 10
}

let bullet = {
  xPos: -20,
  yPos: 600,
  isBullet: false,
  bulletIsShooted: true
}

let asteroid = {
  speed: 5,
  xPos: 350,
  yPos: -50,
  asteroidIsDown: false
}

let alien = {
  speed: 10,
  xPos: -20,
  yPos: -275,
  alienIsDown: false,
  alienTimer: 100
}

let bigAsteroid = {
  speed: 2,
  xPos: 350,
  yPos: -200,
  bigAsteroidIsDown: false,
  bigAsteroidIsLost: false,
  stage: 1
}

function drawCanvas()
{
  stroke(200, 70, 30)
  strokeWeight(3)
  fill(0)
  
  stroke(100, 30, 70)
  square(5, 5, 690)
  quad(245, 0, 277, 75, 423, 75, 455, 0)
  quad(-10, 656, 30, 696, 30, 529, -10, 574)
  quad(710, 656, 670, 696, 670, 529, 710, 574)
  
  stroke(200, 70, 30)
  square(10, 10, 680)
  quad(250, 0, 280, 70, 420, 70, 450, 0)
  quad(-5, 653, 25, 683, 25, 542, -5, 577)
  quad(705, 653, 675, 683, 675, 542, 705, 577)
  
  stroke(250, 250, 0)
  square(15, 15, 670)
  quad(255, 0, 283, 65, 417, 65, 445, 0)
  quad(0, 650, 20, 670, 20, 555, 0, 580)
  quad(700, 650, 680, 670, 680, 555, 700, 580)
  
  noStroke()
  fill(0)
  quad(17, 500, 683, 500, 683, 685, 17, 685)
  
  fill(250, 250, 0)
  
  if(score < 0)
  {
    stroke(250, 50, 0)
    strokeWeight(1)
    fill(250, 50, 0)
    text(`ATTENTION`, 295, 25)
    text(`SCORE: ${score}`, 305, 50)
  }
  else
  {
    textSize(20)
    text(`SCORE: ${score}`, 305, 35)
  }
}

function drawShip()
{
  stroke(200, 70, 30)
  strokeWeight(3)
  fill(0)
  triangle(ship.xPos, ship.yPos - 10, ship.xPos - 15, ship.yPos + 40, ship.xPos + 15, ship.yPos + 40)
  stroke(100, 30, 70)
  fill(0)
  triangle(ship.xPos, ship.yPos + 20, ship.xPos - 15, ship.yPos + 40, ship.xPos + 15, ship.yPos + 40)
  noStroke()
  triangle(ship.xPos, ship.yPos + 25, ship.xPos - 15, ship.yPos + 43, ship.xPos + 15, ship.yPos + 43)
  fill(240, 110, 10)
  triangle(ship.xPos, ship.yPos - 16, ship.xPos - 9, ship.yPos + 15, ship.xPos + 9, ship.yPos + 15)
  fill(0)
  triangle(ship.xPos, ship.yPos - 5, ship.xPos - 6, ship.yPos + 15, ship.xPos + 6, ship.yPos + 15)
  
  if(bullet.isBullet)
  {
    fill(250, 250, 0)
    triangle(ship.xPos, ship.yPos - 17, ship.xPos - 6, ship.yPos + 5, ship.xPos + 6, ship.yPos + 5)
    fill(0)
    triangle(ship.xPos, ship.yPos - 5, ship.xPos - 6, ship.yPos + 15, ship.xPos + 6, ship.yPos + 15)
  }
  
}

function drawAsteroid()
{
  fill(0)
  stroke("#556ddb")
  strokeWeight(5)
  circle(asteroid.xPos, asteroid.yPos, 50)
  stroke("#26fb69")
  ellipse(asteroid.xPos, asteroid.yPos + 6, 40, 36)
  stroke("#7719c9")
  ellipse(asteroid.xPos, asteroid.yPos - 7, 40, 36)
  noStroke()
  circle(asteroid.xPos, asteroid.yPos, 46)
}

function drawAlien()
{
  fill(0)
  stroke(255)
  strokeWeight(4)
  stroke("#7719c9")
  circle(alien.xPos, alien.yPos - 20, 30)
  stroke("#556ddb")
  arc(alien.xPos, alien.yPos, 60, 40, 3.15, PI + PI)
  
  stroke("#26fb69")
  strokeWeight(5)
  arc(alien.xPos, alien.yPos, 60, 25, 0, PI)
  
  noStroke()
  circle(alien.xPos, alien.yPos - 20, 25)
}

function drawBigAsteroid()
{
  if(bigAsteroid.stage == 1)
  {
    fill(0)
    strokeWeight(4)
    stroke(255)
    stroke("#26fb69")
    circle(bigAsteroid.xPos, bigAsteroid.yPos, 80)
    stroke("#556ddb")
    circle(bigAsteroid.xPos + 30, bigAsteroid.yPos - 10, 60)
    circle(bigAsteroid.xPos - 35, bigAsteroid.yPos - 5, 40)

    stroke("#7719c9")
    arc(bigAsteroid.xPos, bigAsteroid.yPos, 80, 80, 3, PI + PI)
    arc(bigAsteroid.xPos + 30, bigAsteroid.yPos - 10, 60, 60, 3, PI + PI)
    arc(bigAsteroid.xPos - 35, bigAsteroid.yPos - 5, 40, 40, 4, PI + PI)

    noStroke()
    circle(bigAsteroid.xPos, bigAsteroid.yPos, 76)
    circle(bigAsteroid.xPos + 30, bigAsteroid.yPos - 10, 56)
    circle(bigAsteroid.xPos - 35, bigAsteroid.yPos - 5, 36)
  }
  
  if(bigAsteroid.stage == 2)
  {
    fill(0)
    strokeWeight(4)

    stroke("#556ddb")
    circle(bigAsteroid.xPos + 30, bigAsteroid.yPos - 10, 60)
    arc(bigAsteroid.xPos, bigAsteroid.yPos, 80, 80, 3, PI + PI)
    
    stroke("#7719c9")
    arc(bigAsteroid.xPos, bigAsteroid.yPos, 80, 80, 3.5, HALF_PI)
    arc(bigAsteroid.xPos + 30, bigAsteroid.yPos - 10, 60, 60, 3, PI + PI)
    
    stroke("#26fb69")
    arc(bigAsteroid.xPos, bigAsteroid.yPos, 80, 80, 0, PI)

    noStroke()
    circle(bigAsteroid.xPos, bigAsteroid.yPos, 76)
    circle(bigAsteroid.xPos + 30, bigAsteroid.yPos - 10, 56)
  }
  
  if(bigAsteroid.stage == 3)
  {
    fill(0)
    strokeWeight(4)
    stroke(255)
    stroke("#26fb69")
    circle(bigAsteroid.xPos, bigAsteroid.yPos, 80)

    stroke("#556ddb")
    arc(bigAsteroid.xPos, bigAsteroid.yPos, 80, 80, -4, PI + HALF_PI)
    stroke("#556ddb")
    arc(bigAsteroid.xPos, bigAsteroid.yPos, 80, 80, -1, HALF_PI - QUARTER_PI)
    stroke("#7719c9")
    arc(bigAsteroid.xPos, bigAsteroid.yPos, 80, 80, 3, PI + PI)
  }
}

function drawExplosion(xPos, yPos)
{
  fill(0)
  strokeWeight(3)
  stroke(200, 70, 30)
  circle(xPos, yPos, 90)
  stroke(250, 250, 0)
  circle(xPos, yPos, 75)
  stroke(255)
  circle(xPos, yPos, 30)
}

function drawBullet()
{
  noStroke()
  fill(250, 250, 0)
  ellipse(bullet.xPos, bullet.yPos - 10, 4, 30)
  fill(200, 70, 30)
  ellipse(bullet.xPos, bullet.yPos, 4, 30)
  fill(100, 30, 70)
  ellipse(bullet.xPos, bullet.yPos + 5, 4, 20)
}

function preload()
{
  music = loadSound("Toby Fox — A Simple Diversion (www.lightaudio.ru).mp3")
  explosionSound = loadSound("snd_bomb.mp3")
}

function setup()
{
  createCanvas(700, 700)
  
  asteroid.x_pos = int(random(50, 650))
  
  music.loop()
  
  musicButton = createButton("❚❚")
  musicButton.mousePressed(togglePlaying)
  musicButton.position(630, 38)
  musicButton.style('color:yellow')
  musicButton.style('background-color:black')
  musicButton.style('border-color:yellow')
  musicButton.size(30, 30)
  
  musicSlider = createSlider(0, 4, 2)
  musicSlider.position(480, 28)
  
  soundSlider = createSlider(0, 4, 2)
  soundSlider.position(480, 58)
}

function togglePlaying()
{
  if(!music.isPlaying())
  {
    music.loop()
    musicButton.html("❚❚")
  }
  
  else
  {
    music.pause()
    musicButton.html("▶")
  }
}

function draw()
{ 
  music.setVolume(musicSlider.value())
  explosionSound.setVolume(soundSlider.value())
  
  if(score < minScore || score >= maxScore)
  {
    gameEnded = true
    endTheGame()
  }
  
  if(!gameEnded)
  {
    background(0)
  
    drawCanvas()
  
    drawShip()
  
    cornersReturn() // Движение через края
  
    flyAsteroid() // Астероид и его функции
    
    flyAlien() // Инопланетянин и его функции
    
    flyBigAsteroid() // Большой астероид и его функции
  
    if(keyIsPressed) // Проверка на движение
    {
      move()
    }
  
    if(ship.canShoot && keyIsDown(32)) // Пуля начинает летель
    {
      bullet.isBullet = true
    }
  
    if(bullet.isBullet) // Отключение возможности стрелять пока летит пуля
    {
      ship.canShoot = false
      shoot()
    }
    
    if(abs(asteroid.yPos - bullet.yPos) < 40 && bullet.xPos != -20) // Столкновение астероида и пули
    {
      if(abs(asteroid.xPos - bullet.xPos) < 40)
      {
        if(music.isPlaying())
        {
          explosionSound.play()
        }
        
        bullet.yPos = -100
        asteroid.asteroidIsDown = true
        score += 1
      }
    } 
    
    if(abs(alien.yPos - bullet.yPos) < 40 && bullet.xPos != -20) // Столкновение НЛО и пули
    {
      if(abs(alien.xPos - bullet.xPos) < 50)
      {
        if(music.isPlaying())
        {
          explosionSound.play()
        }
        
        bullet.yPos = -100
        alien.alienIsDown = true
        score += 3
      }
    } 
    
    if(abs(bigAsteroid.yPos - bullet.yPos) < 60 && bullet.xPos != -20) // Столкновение большого астероида и пули
    {
      if(abs(bigAsteroid.xPos - bullet.xPos) < 60)
      {
        if(music.isPlaying())
        {
          explosionSound.play()
        }
        
        bullet.yPos = -100

        if(bigAsteroid.stage == 3)
        {
          score += 1
          bigAsteroid.bigAsteroidIsDown = true
        }
        
        if(bigAsteroid.stage == 2)
        {
          score += 1
          bigAsteroid.stage += 1
        }
        
        if(bigAsteroid.stage == 1)
        {
          score += 1
          bigAsteroid.stage += 1
        }
      }
    }
  }
}

function cornersReturn() 
{
  if(ship.xPos > 710)
  {
    ship.xPos = -10
  }
  
  if(ship.xPos < -10)
  {
    ship.xPos = 710
  }
}

function move()
{
    if (keyIsDown(65)) // Движение влево
    {   
      ship.xPos = ship.xPos - 8
    }
    

    if (keyIsDown(68)) // Движение вправо
    {    
      ship.xPos = ship.xPos + 8
    }
}

function shoot()
{
  drawBullet()
  
  bullet.yPos -= 20
  
  if(bullet.yPos < 0)
  {
    bullet.isBullet = false
    ship.canShoot = true
    bullet.yPos = 600
    bullet.xPos = -20
    bullet.bulletIsShooted = true
  }
  
  if(bullet.bulletIsShooted && bullet.isBullet) // Вырарнивание пули по оси X на момент выстрела
  {
    bullet.xPos = ship.xPos
    bullet.bulletIsShooted = false
  }
}

function flyAsteroid()
{
    drawAsteroid()
  
    asteroid.yPos += asteroid.speed
  
    if(asteroid.yPos > 740) // Астероид пролетает нижнюю границу
    {
      asteroid.asteroidIsDown = true
      score -= 1
    }
    
    if(asteroid.asteroidIsDown) // Взрывающийся астероид + Респавн астероида по оси X после уничтожения
    {
      drawExplosion(asteroid.xPos, asteroid.yPos)
      
      asteroid.asteroidIsDown = false
      asteroid.yPos = -50
      asteroid.xPos = int(random(50, 650))
      
      if(score < 25)
      {
        asteroid.speed = int(random(5, 8))
      }
      
      else if(score < 35)
      {
        asteroid.speed = int(random(9, 11))
      }
      
      else
      {
        asteroid.speed = int(random(12, 14))
      }
    }

}

function flyAlien()
{
  drawAlien()
  
  alien.xPos += alien.speed
  
  if(alien.xPos > 720)
  {
    alien.xPos = -20
    alien.yPos += 130
  }
  
  if(alien.yPos > 550)
  {
    alien.xPos = -20
    alien.yPos = -275
    score -= 5
  }
  
  if(alien.alienIsDown) // Взрывающееся НЛО  + Респавн НЛО после уничтожения
    {
      drawExplosion(alien.xPos, alien.yPos)
      
      alien.alienIsDown = false
      alien.yPos = -20
      alien.xPos = -275
      
      if(score < 30)
      {
        alien.speed = int(random(12, 14))
      }
      
      else
      {
        alien.speed = int(random(15, 18))
      }
    }
}

function flyBigAsteroid()
{
  drawBigAsteroid()
  
  bigAsteroid.yPos += bigAsteroid.speed
  
  if(bigAsteroid.yPos > 750)
  {
    bigAsteroid.yPos = -200
    bigAsteroid.stage = 1
    
    if(score >= 5)
    {
      score -= 10
    }
    
    else
    {
      score = -5
    }
  }
  
  if(bigAsteroid.bigAsteroidIsDown) // Взрывающийся большой астероид  + Респавн после уничтожения
    {
      drawExplosion(bigAsteroid.xPos, bigAsteroid.yPos)
      
      bigAsteroid.bigAsteroidIsDown = false
      bigAsteroid.yPos = -200
      bigAsteroid.xPos = int(random(100, 600))
      bigAsteroid.stage = 1
    }
}

function endTheGame()
{
  fill(0)
  square(0, 0, 700)
  
  if(score < minScore)
  {
    stroke(250, 0, 0)
    square(10, 10, 680)
    noStroke()
    fill(250, 0, 0)
    textSize(80)
    text(`YOU LOST`, 150, 350)
    
    if(keyIsDown(69))
    {
      score = 0
      gameEnded = false
      
      alien.xPos = -20
      alien.yPos = -275
    }
  }

  else if(score >= maxScore)
  {
    stroke(0, 250, 0)
    square(10, 10, 680)
    noStroke()
    fill(0, 250, 0)
    textSize(80)
    text(`YOU WON`, 160, 350)
    
    if(keyIsDown(69))
    {
      score = 0
      gameEnded = false
      
      alien.xPos = -20
      alien.yPos = -275
    }
  }
}